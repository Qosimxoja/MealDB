package uz.kosimkhujasharipov.mealdb.core.models.aboutUs

class SocialNetworkData(val name: String, val image: String) {
    companion object {
        fun socialNetworkData(): ArrayList<SocialNetworkData> {
            return arrayListOf(
                SocialNetworkData(
                    "Instagram",
                    "https://e7.pngegg.com/pngimages/704/270/png-clipart-social-media-instagram-login-graphy-ig-instagram-icon-rectangle-magenta-thumbnail.png"
                ),
                SocialNetworkData(
                    "Facebook",
                    "https://e7.pngegg.com/pngimages/670/159/png-clipart-facebook-logo-social-media-facebook-computer-icons-linkedin-logo-facebook-icon-media-internet-thumbnail.png"
                ),
                SocialNetworkData(
                    "LinkedIn",
                    "https://e7.pngegg.com/pngimages/796/374/png-clipart-linkedin-linkedin-thumbnail.png"
                ),
                SocialNetworkData(
                    "Email",
                    "https://e7.pngegg.com/pngimages/611/356/png-clipart-email-computer-icons-email-miscellaneous-blue-thumbnail.png"
                ),
            )
        }
    }
}