package uz.kosimkhujasharipov.mealdb.view.fragments

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import uz.kosimkhujasharipov.mealdb.core.adapters.aboutUs.AboutUsAdapter
import uz.kosimkhujasharipov.mealdb.core.models.aboutUs.SocialNetworkData
import uz.kosimkhujasharipov.mealdb.databinding.AboutUsFragmentBinding

class AboutUsFragment : Fragment() {

    private lateinit var binding: AboutUsFragmentBinding
    private val adapter = AboutUsAdapter()

    override fun onAttach(context: Context) {
        super.onAttach(context)
        // loading view
        binding = AboutUsFragmentBinding.inflate(layoutInflater)
        // preparing list
        binding.list.adapter = adapter
        binding.list.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        // loading data
        adapter.data = SocialNetworkData.socialNetworkData()
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return binding.root
    }

}