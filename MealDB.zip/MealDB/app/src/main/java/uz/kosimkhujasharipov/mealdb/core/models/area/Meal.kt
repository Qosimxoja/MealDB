package uz.kosimkhujasharipov.mealdb.core.models.area


import com.google.gson.annotations.SerializedName

data class Meal(
    @SerializedName("strArea")
    val strArea: String
)